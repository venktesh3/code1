import java.util.Scanner;

public class SelectionSort {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter size of Array");
		int n = in.nextInt();
		
		int nums[] = new int[1000];
		
		System.out.println("Enter elements in array:");
		for (int i = 0; i < n; i++) {
			nums[i] = in.nextInt();
		}
		
		System.out.println("Entered Array is :");
		for (int i = 0; i < n; i++) {
			System.out.print(nums[i] + " ");
		}
		
		for (int i = 0; i < n; i++) {
			int min = i;
			for (int j = i + 1; j < n; j++) {
				if (nums[j] < nums[min]) {
					min = j;
				}
			}
				int temp = nums[min];
				nums[min] = nums[i];
				nums[i] = temp;
		}
		
		System.out.println("Sorted Array after selection Sort is : ");
		for (int i = 0; i < n; i++) {
			System.out.print(nums[i] + " ");
		}
	}
}